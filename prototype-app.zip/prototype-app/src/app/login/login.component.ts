import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prototype-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor() {}
  ngOnInit() {
      console.log('Login component initiated =>');
  }
}